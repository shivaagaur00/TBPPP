// const out=document.getElementById("hi");
// console.log(out);
// out.style.color='red';
// const hi2=document.getElementsByClassName("hi2");
// for(let hii2 of hi2){
//     hii2.style.color='green';
// }
// const btn=document.querySelector('#btn');
btn.addEventListener('click',()=>{
    console.log('clicked');
    fetch('https://official-joke-api.appspot.com/random_joke')
    .then((res)=>{
        // console.log(res);
        return res.json();
    })
    .then((data)=>{
        console.log(data)
    })
    .catch((err)=>{
        console.log(err);
    })
})

// let pr=new Promise((resolve,reject)=>{

// })